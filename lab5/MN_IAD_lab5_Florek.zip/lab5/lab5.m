a = [1 5 5 5];
b = [2 2 2];

[d, s] = rozklad(a,b)